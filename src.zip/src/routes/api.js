const express = require("express");
const { rateLimit } = require("../middleware/rateLimit");
const {
  normalizeSerial,
  normalizePhone,
  normalizeEmail,
  cleanText,
  cleanMessage,
} = require("../utils/validate");

const fail = (res, status, code, message, extra = {}) =>
  res.status(status).json({ success: false, code, message, ...extra });

/** Runs a send and always returns a promise, even if the sender throws straight away. */
const attempt = (fn) => Promise.resolve().then(fn);

const settled = (result) =>
  result.status === "fulfilled"
    ? { sent: true, error: null }
    : { sent: false, error: String(result.reason?.message || result.reason || "failed").slice(0, 300) };

function createApiRouter({ db, products, sms, mailer, incidents }) {
  const router = express.Router();

  const writeLimit = rateLimit({ windowMs: 10 * 60 * 1000, max: 30 });
  const readLimit = rateLimit({ windowMs: 60 * 1000, max: 120 });
  // Stricter: this lookup is keyed by phone number, so slow down anyone trying many numbers
  const lookupLimit = rateLimit({ windowMs: 10 * 60 * 1000, max: 20 });

  // ------------------------------------------------------------------
  // GET /api/products/:serial
  // Called as soon as the QR is scanned. Tells the frontend whether the
  // serial number is genuine and whether it can still be registered.
  // ------------------------------------------------------------------
  router.get("/products/:serial", readLimit, async (req, res, next) => {
    try {
      const serial = normalizeSerial(req.params.serial);
      if (!serial) {
        return fail(res, 400, "INVALID_SERIAL", "Invalid QR code. Please scan a valid product QR code.", {
          valid: false,
        });
      }

      const data = await products.find(serial);
      if (!data) {
        return fail(res, 404, "SERIAL_NOT_FOUND", "Invalid QR code. This product could not be verified.", {
          valid: false,
        });
      }

      const product = products.toPublic(serial, data);
      return res.json({
        success: true,
        valid: true,
        canRegister: !product.isRegistered,
        message: product.isRegistered
          ? "This product is already registered."
          : "Genuine product. You can register it now.",
        product,
      });
    } catch (err) {
      return next(err);
    }
  });

  // ------------------------------------------------------------------
  // POST /api/customers/products      body: { phone }
  // Every product registered with this phone number (used by My Favorites).
  // The phone number is sent in the body, not the URL, so it stays out of logs.
  // ------------------------------------------------------------------
  router.post("/customers/products", lookupLimit, async (req, res, next) => {
    try {
      const phone = normalizePhone((req.body || {}).phone);
      if (!phone) return fail(res, 400, "INVALID_PHONE", "Please enter a valid 10-digit mobile number.");

      const list = await products.listByPhone(phone);
      return res.json({ success: true, count: list.length, products: list });
    } catch (err) {
      return next(err);
    }
  });

  // ------------------------------------------------------------------
  // POST /api/register
  // body: { serialNumber, name, email, phone, agreedToPolicy }
  // ------------------------------------------------------------------
  router.post("/register", writeLimit, async (req, res, next) => {
    try {
      const body = req.body || {};
      const serial = normalizeSerial(body.serialNumber);
      const customerName = cleanText(body.name ?? body.customerName, 100);
      const phone = normalizePhone(body.phone);
      const email = normalizeEmail(body.email);

      if (!serial) return fail(res, 400, "INVALID_SERIAL", "Invalid QR code.");
      if (!customerName) return fail(res, 400, "NAME_REQUIRED", "Please enter your name.");
      if (!phone) return fail(res, 400, "INVALID_PHONE", "Please enter a valid 10-digit mobile number.");
      if (email === null) return fail(res, 400, "INVALID_EMAIL", "Please enter a valid email address.");
      if (body.agreedToPolicy === false) {
        return fail(res, 400, "POLICY_REQUIRED", "You must agree to the Privacy Policy.");
      }

      const result = await products.register(serial, { customerName, email, phone });

      if (result.status === "not_found") {
        return fail(res, 404, "SERIAL_NOT_FOUND", "Invalid QR code. This product could not be verified.");
      }
      if (result.status === "already_registered") {
        return fail(res, 409, "ALREADY_REGISTERED", "This product is already registered.", {
          product: result.product,
        });
      }

      // Registration is saved. Reply to the customer right away; SMS and email are sent in the
      // background so a slow or blocked provider can never make the registration look failed.
      const { product } = result;

      Promise.allSettled([
        attempt(() => sms.sendRegistrationSms(phone)),
        email
          ? attempt(() => mailer.sendWelcomeEmail({ to: email, customerName }))
          : Promise.reject(new Error("No email address provided")),
      ])
        .then(async ([smsResult, emailResult]) => {
          const notifications = {
            sms: settled(smsResult),
            email: email ? settled(emailResult) : { sent: false, skipped: true, error: null },
          };
          if (!notifications.sms.sent) console.error(`SMS failed for ${serial}:`, notifications.sms.error);
          else console.log(`SMS sent for ${serial}`);
          if (email) {
            if (!notifications.email.sent) console.error(`Email failed for ${serial}:`, notifications.email.error);
            else console.log(`Email sent for ${serial}`);
          }
          await products.saveNotificationStatus(serial, notifications);
        })
        .catch((err) => console.error(`Notification step failed for ${serial}:`, err));

      return res.status(201).json({
        success: true,
        message: "Product registered successfully.",
        product,
        customer: { name: customerName, email, phone },
        notifications: {
          sms: { queued: true },
          email: email ? { queued: true } : { queued: false, skipped: true },
        },
      });
    } catch (err) {
      return next(err);
    }
  });

  // Shared handler for feedback + incident (same fields, different mailbox/collection)
  function customerMessageHandler({ collection, sendMail, okMessage, label, ackKind }) {
    return async (req, res, next) => {
      try {
        const body = req.body || {};
        const serial = normalizeSerial(body.serialNumber);
        const customerName = cleanText(body.name, 100);
        const phone = normalizePhone(body.phone);
        const email = normalizeEmail(body.email);
        const message = cleanMessage(body.message, 2000);

        if (!serial) return fail(res, 400, "INVALID_SERIAL", "Invalid product serial number.");
        if (!customerName) return fail(res, 400, "NAME_REQUIRED", "Please enter your name.");
        if (!phone) return fail(res, 400, "INVALID_PHONE", "Please enter a valid 10-digit mobile number.");
        if (email === null) return fail(res, 400, "INVALID_EMAIL", "Please enter a valid email address.");
        if (!message) return fail(res, 400, "MESSAGE_REQUIRED", "Please enter your message.");

        // Only registered products can send feedback / incidents.
        const data = await products.find(serial);
        if (!data) return fail(res, 404, "SERIAL_NOT_FOUND", "Invalid product serial number.");
        if (data.isRegistered !== true) {
          return fail(res, 403, "NOT_REGISTERED", "Please register the product first.");
        }

        // One shared incident number (INC0000796 ...) for feedback and support requests
        const incidentNumber = await incidents.next();

        const record = {
          incidentNumber,
          serialNumber: serial,
          productName: data.productName || "",
          customerName,
          email,
          phone,
          message,
          createdAt: new Date(),
          emailSent: false,
          customerEmailSent: false,
        };

        // Save first so nothing is lost even if the email server is down.
        const docRef = await db.collection(collection).add(record);

        // Send the emails in the background so a slow mail server never delays the customer:
        //   - the company mailbox gets the full message
        //   - the customer gets the "we received your request" email (only if an email was entered)
        Promise.allSettled([
          attempt(() => sendMail(record)),
          email
            ? attempt(() =>
                mailer.sendAcknowledgementEmail({
                  to: email,
                  kind: ackKind,
                  customerName,
                  productName: record.productName,
                  incidentNumber,
                })
              )
            : Promise.reject(new Error("No email address provided")),
        ])
          .then(async ([companyResult, customerResult]) => {
            const update = {
              emailSent: companyResult.status === "fulfilled",
              customerEmailSent: customerResult.status === "fulfilled",
            };
            if (companyResult.status === "rejected") {
              update.emailError = String(companyResult.reason?.message || companyResult.reason).slice(0, 300);
              console.error(`${label} email to company failed for ${incidentNumber}:`, update.emailError);
            } else {
              console.log(`${label} email sent to company for ${incidentNumber}`);
            }
            if (email) {
              if (customerResult.status === "rejected") {
                update.customerEmailError = String(customerResult.reason?.message || customerResult.reason).slice(0, 300);
                console.error(`${label} confirmation to customer failed for ${incidentNumber}:`, update.customerEmailError);
              } else {
                console.log(`${label} confirmation sent to customer for ${incidentNumber}`);
              }
            }
            await docRef.update(update);
          })
          .catch((err) => console.error(`${label} email step failed for ${incidentNumber}:`, err));

        return res.status(201).json({ success: true, id: docRef.id, incidentNumber, message: okMessage });
      } catch (err) {
        return next(err);
      }
    };
  }

  // POST /api/feedback  body: { serialNumber, name, email, phone, message }
  router.post(
    "/feedback",
    writeLimit,
    customerMessageHandler({
      collection: "feedback",
      sendMail: (r) => mailer.sendFeedbackEmail(r),
      okMessage: "Thank you for your valuable inputs. We shall get back to you shortly.",
      label: "Feedback",
      ackKind: "feedback",
    })
  );

  // POST /api/incidents  body: { serialNumber, name, email, phone, message }
  router.post(
    "/incidents",
    writeLimit,
    customerMessageHandler({
      collection: "incidents",
      sendMail: (r) => mailer.sendIncidentEmail(r),
      okMessage: "Thank you for your valuable inputs. We shall get back to you shortly.",
      label: "Incident",
      ackKind: "incident",
    })
  );

  return router;
}

module.exports = { createApiRouter };